# -*- coding: utf-8 -*-

from odoo import models, fields, api


class genralpharmacy(models.Model):
    _name = 'genralpharmacy.genralpharmacy'
    _description = 'genralpharmacy.genralpharmacy'

     